// js_topo/topo.js — Topology graphics plugin
// Plugin API v1 + graphics: get_info() + parse(frame) + render(p,w,h)
//   + on_event(type,x,y,button,modifiers,delta)
// Maintains a node set from mpdu srcTei/dstTei; render() draws the topology
// (CCO at center, STA nodes on a circle, links between them);
// clicking a node selects it (on_event returns true => redraw).

var g_nodes = {};  // tei -> {tei, x, y, count}
var g_order = [];  // insertion order of TEIs
var g_selected = -1;
var NODE_R = 18;

var EVT_PRESS = 0;

function get_info() {
    return {
        protocolId: "JSTOPO_2024",
        displayName: "JS Topology View"
    };
}

function add_node(tei) {
    if (tei === 0) return;
    if (!g_nodes[tei]) {
        g_nodes[tei] = { tei: tei, x: 0, y: 0, count: 0 };
        g_order.push(tei);
    }
    g_nodes[tei].count += 1;
}

function parse(frame) {
    var bytes = frame.data || [];
    var srcTei = bytes.length > 2 ? bytes[2] : 0;
    var dstTei = bytes.length > 3 ? bytes[3] : 0;
    add_node(srcTei);
    add_node(dstTei);
    return {
        accept: true,
        summary: "Topo: TEI " + srcTei + " -> TEI " + dstTei,
        mpdu: { frameType: 1, srcTei: srcTei, dstTei: dstTei },
        fields: [
            { name: "SrcTei", value: String(srcTei) },
            { name: "DstTei", value: String(dstTei) },
            { name: "KnownNodes", value: String(g_order.length) }
        ]
    };
}

// Layout: TEI 1 (CCO) at center when seen, others on a circle.
function layout(w, h) {
    var cx = w / 2, cy = h / 2;
    var ring = g_order.filter(function (t) { return t !== 1; });
    var n = ring.length;
    var radius = Math.min(w, h) / 2 - 40;
    if (radius < 20) radius = 20;
    for (var i = 0; i < n; i++) {
        var a = (2 * Math.PI * i) / n - Math.PI / 2;
        var node = g_nodes[ring[i]];
        node.x = cx + radius * Math.cos(a);
        node.y = cy + radius * Math.sin(a);
    }
    if (g_nodes[1]) {
        g_nodes[1].x = cx;
        g_nodes[1].y = cy;
    }
}

function render(p, w, h) {
    p.clear("#1e1e1e");
    layout(w, h);
    var cx = w / 2, cy = h / 2;

    if (g_order.length === 0) {
        p.set_pen("#888888", 1);
        p.set_font("sans", 12, false);
        p.draw_text(20, 30, "No nodes yet - waiting for frames...");
        return;
    }

    // Links: center -> each STA node
    p.set_pen("#3a7bd5", 1.5);
    for (var i = 0; i < g_order.length; i++) {
        var node = g_nodes[g_order[i]];
        if (node.tei === 1) continue;
        p.draw_line(cx, cy, node.x, node.y);
    }

    // Nodes
    for (var j = 0; j < g_order.length; j++) {
        var nd = g_nodes[g_order[j]];
        var selected = (nd.tei === g_selected);
        p.set_pen(selected ? "#ffd166" : "#ffffff", selected ? 3 : 2);
        p.set_brush(nd.tei === 1 ? "#06d6a0" : "#118ab2");
        p.draw_ellipse(nd.x - NODE_R, nd.y - NODE_R, NODE_R * 2, NODE_R * 2);
        p.set_pen("#ffffff", 1);
        p.set_font("sans", 10, false);
        p.draw_text(nd.x - 14, nd.y + 4, "TEI" + nd.tei);
    }

    // Selection info bar
    if (g_selected !== -1 && g_nodes[g_selected]) {
        var sel = g_nodes[g_selected];
        p.set_pen("#ffd166", 1);
        p.set_font("sans", 11, true);
        p.draw_text(10, 22, "Selected: TEI " + sel.tei +
            " (" + sel.count + " frames)" +
            (sel.tei === 1 ? " [CCO]" : " [STA]"));
    }
}

function on_event(type, x, y, button, modifiers, delta) {
    if (type !== EVT_PRESS) return false;  // only handle clicks
    for (var i = 0; i < g_order.length; i++) {
        var node = g_nodes[g_order[i]];
        var dx = x - node.x, dy = y - node.y;
        if (dx * dx + dy * dy <= NODE_R * NODE_R) {
            g_selected = (g_selected === node.tei) ? -1 : node.tei;
            return true;  // needs redraw
        }
    }
    if (g_selected !== -1) {
        g_selected = -1;
        return true;  // click on empty space clears selection
    }
    return false;
}
