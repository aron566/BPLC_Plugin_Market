# JS 拓扑图 (js-topo)

测试插件：从解析帧中提取 TEI，绘制网络拓扑图，支持点击节点选中。

## 功能

- 实时拓扑绘制：节点 = STA（TEI），边 = 邻居/代理关系
- 右侧映射表：TEI / MAC / 状态 / 层级 / 邻居 / 代理
- 底部帧记录：Frame / Time / Type / NID / Description
- 双击帧记录：调用 `host.jumpToFrame` 让主界面定位到该帧
- 历史冻结：单击主界面较早的帧时，拓扑按完整事件日志重放冻结到该帧

## 插件设置

| 设置 | 说明 | 默认值 |
|---|---|---|
| `max_nodes` | 拓扑图最多绘制的节点数 | 200 |
| `show_labels` | 是否显示节点 TEI/MAC 标签 | true |
| `layout` | 布局算法：`auto` / `circular` / `grid` | `auto` |

脚本内读取示例：

```js
const maxNodes = host.getSetting("max_nodes", 200);
const appVer = host.getEnv("BPLC_APP_VERSION");
```

## 版本历史

- v1.4.0：节点标签 MAC/接入方式字号与标题一致；图区右上角 Fit 按钮（一键复位缩放平移）
- v1.3.0：当前版本（帧记录过滤对齐 / 滚动条 / 图缩放平移 / 主题实时跟随）
- v1.2.0：主题对齐 / 邻居表双击弹窗 / 成功率对齐
- v1.1.0：对齐原版 TOPO（NID选择/映射表/帧记录/悬浮成功率）
- v1.0.0：初始测试版本

---

## English

Test plugin: draws the network topology from frame TEIs, click a node to select.

Settings: `max_nodes` (default 200), `show_labels` (default true),
`layout` (`auto`/`circular`/`grid`, default `auto`).
Read them in script via `host.getSetting(key, default)`; common
environment variables via `host.getEnv(name)` (e.g. `BPLC_APP_VERSION`).
